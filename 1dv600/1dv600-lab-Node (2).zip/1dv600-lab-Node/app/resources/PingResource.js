(function () {
    "use strict";

    var LibraryDAO = require('../dao/LibraryDAO');

    module.exports = function (callback) {
        callback('{"answer": "pong"}');
    };

}());
